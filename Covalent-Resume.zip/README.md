# Covalent theme for resumes

A theme for the Ghost blogging platform, forked from Covalent. Demo available on [www.tracykennedy.io](http://www.tracykennedy.io).

# Install

* Download the zip file of this repo
* Upload to Ghost as a custom theme and restart
* Under "Settings", select this theme.

# Changes
* Streamlined into resume-friendly format by:

	* Removing Disqus integration

	* Removing date stamps 

	* Removing "blog" text previews

	* Removing "blog" subscribe options
